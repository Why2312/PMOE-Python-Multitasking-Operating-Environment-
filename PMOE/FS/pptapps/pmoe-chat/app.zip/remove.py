import FS.lib.util as util
import os

util.delete_file(os.path.join(rwd, "bin", "chat.py"))