#testing boot file.
import time


print("Hello world from test.py!!")
time.sleep(2)