#ALL IN ONE installer

#We are going to use the same init.py code, but instead of booting the shell, we will launch the installer.

import os
import time
import sys
import psutil
import zipfile

from os import system, name
def clear():
    if name == 'nt':
        _ = system('cls')
    else:
        _ = system('clear')
clear()

def slow_type(t,s):
    for l in t:
        sys.stdout.write(l)
        sys.stdout.flush()
        time.sleep(1*10.0/s)
    print('')


global rwd

rwd = os.getcwd()

print("Starting install script, please wait for file init ", end="")

current_path = os.getcwd()
current_drive = os.path.splitdrive(current_path)[0]


size_limit = 32 * 1024 * 1024
space_limit = 32 * 1024


slow_type("...", 15)

zipf = rwd + "\\PMOE.zip"

print()
print("Available disks:")

def bytes2human(n, format="%(value)i%(symbol)s"):
    symbols = ('B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
    prefix = {}
    for i, s in enumerate(symbols[1:]):
        prefix[s] = 1 << (i+1)*10
    for symbol in reversed(symbols[1:]):
        if n >= prefix[symbol]:
            value = float(n) / prefix[symbol]
            return format % locals()
    return format % dict(symbol=symbols[0], value=n)

availabledrives = []
actualdrives = []

for partition in psutil.disk_partitions():
    if 'fixed' in partition.opts:
        usage = psutil.disk_usage(partition.mountpoint)
        if usage.total > size_limit and usage.used < space_limit:
            print(f"Drive {partition.device} with {bytes2human(usage.total)}")
            actualdrives.append(partition.device)
            drive_letter = partition.device[:1]
            availabledrives.append(drive_letter)
            print(drive_letter)
drive = input("Drive letter>")
while not drive in availabledrives:
    drive = input("Drive letter>")

for i in range(len(availabledrives)):
    if drive == availabledrives[i]:
        actual_drive = actualdrives[i]

clear()
print(f"INSTALLING TO {drive} DRIVE, DO NOT SHUTDOWN.")

print("Decompressing commands    ", end="")
slow_type("........", 5)
print("Copying commands          ", end="")
slow_type("........", 7)
print("Decompressing shell.py    ", end="")
slow_type("........", 9)
print("Copying shell.py          ", end="")
slow_type("........", 12)
print("Finishing up              ", end="")
slow_type("........", 8)

with zipfile.ZipFile(zipf, 'r') as zObject:
    zObject.extractall(path=actual_drive)
